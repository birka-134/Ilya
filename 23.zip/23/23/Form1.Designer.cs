﻿
namespace _23
{
	partial class PainLite
	{
		/// <summary>
		/// Обязательная переменная конструктора.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Освободить все используемые ресурсы.
		/// </summary>
		/// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Код, автоматически созданный конструктором форм Windows

		/// <summary>
		/// Требуемый метод для поддержки конструктора — не изменяйте 
		/// содержимое этого метода с помощью редактора кода.
		/// </summary>
		private void InitializeComponent()
		{
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PainLite));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.file = new System.Windows.Forms.ToolStripMenuItem();
            this.newToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.open = new System.Windows.Forms.ToolStripMenuItem();
            this.save = new System.Windows.Forms.ToolStripMenuItem();
            this.exit = new System.Windows.Forms.ToolStripMenuItem();
            this.edit = new System.Windows.Forms.ToolStripMenuItem();
            this.undo = new System.Windows.Forms.ToolStripMenuItem();
            this.reno = new System.Windows.Forms.ToolStripMenuItem();
            this.pen = new System.Windows.Forms.ToolStripMenuItem();
            this.style = new System.Windows.Forms.ToolStripMenuItem();
            this.solid = new System.Windows.Forms.ToolStripMenuItem();
            this.dot = new System.Windows.Forms.ToolStripMenuItem();
            this.dashDotDot = new System.Windows.Forms.ToolStripMenuItem();
            this.color11 = new System.Windows.Forms.ToolStripMenuItem();
            this.help = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutF1 = new System.Windows.Forms.ToolStripMenuItem();
            this.picDrawingSurface = new System.Windows.Forms.PictureBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.tt = new System.Windows.Forms.Label();
            this.width = new System.Windows.Forms.TrackBar();
            this.instrument_panel = new System.Windows.Forms.ToolStrip();
            this.upload = new System.Windows.Forms.ToolStripButton();
            this.save1 = new System.Windows.Forms.ToolStripButton();
            this.open1 = new System.Windows.Forms.ToolStripButton();
            this.color1 = new System.Windows.Forms.ToolStripButton();
            this.exit1 = new System.Windows.Forms.ToolStripButton();
            this.panel2 = new System.Windows.Forms.Panel();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picDrawingSurface)).BeginInit();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.width)).BeginInit();
            this.instrument_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.file,
            this.edit,
            this.help});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(999, 24);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // file
            // 
            this.file.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.newToolStripMenuItem,
            this.open,
            this.save,
            this.exit});
            this.file.Name = "file";
            this.file.Size = new System.Drawing.Size(37, 20);
            this.file.Text = "File";
            // 
            // newToolStripMenuItem
            // 
            this.newToolStripMenuItem.Image = ((System.Drawing.Image)(resources.GetObject("newToolStripMenuItem.Image")));
            this.newToolStripMenuItem.Name = "newToolStripMenuItem";
            this.newToolStripMenuItem.ShortcutKeyDisplayString = "CTRL+N";
            this.newToolStripMenuItem.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.N)));
            this.newToolStripMenuItem.Size = new System.Drawing.Size(185, 22);
            this.newToolStripMenuItem.Text = "New            ";
            this.newToolStripMenuItem.Click += new System.EventHandler(this.newToolStripMenuItem_Click);
            // 
            // open
            // 
            this.open.Image = ((System.Drawing.Image)(resources.GetObject("open.Image")));
            this.open.Name = "open";
            this.open.ShortcutKeyDisplayString = "F3";
            this.open.ShortcutKeys = System.Windows.Forms.Keys.F3;
            this.open.Size = new System.Drawing.Size(185, 22);
            this.open.Text = "Open";
            this.open.Click += new System.EventHandler(this.open_Click);
            // 
            // save
            // 
            this.save.Image = ((System.Drawing.Image)(resources.GetObject("save.Image")));
            this.save.Name = "save";
            this.save.ShortcutKeyDisplayString = "F2";
            this.save.ShortcutKeys = System.Windows.Forms.Keys.F2;
            this.save.Size = new System.Drawing.Size(185, 22);
            this.save.Text = "Save ";
            this.save.Click += new System.EventHandler(this.saveToolStripMenuItem_Click);
            // 
            // exit
            // 
            this.exit.Image = ((System.Drawing.Image)(resources.GetObject("exit.Image")));
            this.exit.Name = "exit";
            this.exit.ShortcutKeyDisplayString = "Alt+X";
            this.exit.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Alt | System.Windows.Forms.Keys.X)));
            this.exit.Size = new System.Drawing.Size(185, 22);
            this.exit.Text = "Exit             ";
            this.exit.Click += new System.EventHandler(this.exit_Click);
            // 
            // edit
            // 
            this.edit.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.undo,
            this.reno,
            this.pen});
            this.edit.Name = "edit";
            this.edit.Size = new System.Drawing.Size(39, 20);
            this.edit.Text = "Edit";
            // 
            // undo
            // 
            this.undo.Image = ((System.Drawing.Image)(resources.GetObject("undo.Image")));
            this.undo.Name = "undo";
            this.undo.ShortcutKeyDisplayString = "CTRL+Z";
            this.undo.ShortcutKeys = ((System.Windows.Forms.Keys)((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Z)));
            this.undo.Size = new System.Drawing.Size(197, 22);
            this.undo.Text = "Undo         ";
            this.undo.Click += new System.EventHandler(this.undo_Click);
            // 
            // reno
            // 
            this.reno.Image = ((System.Drawing.Image)(resources.GetObject("reno.Image")));
            this.reno.Name = "reno";
            this.reno.ShortcutKeyDisplayString = "CTRL+Shift+Z";
            this.reno.ShortcutKeys = ((System.Windows.Forms.Keys)(((System.Windows.Forms.Keys.Control | System.Windows.Forms.Keys.Shift) 
            | System.Windows.Forms.Keys.Z)));
            this.reno.Size = new System.Drawing.Size(197, 22);
            this.reno.Text = "Reno     ";
            this.reno.Click += new System.EventHandler(this.reno_Click);
            // 
            // pen
            // 
            this.pen.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.style,
            this.color11});
            this.pen.Image = ((System.Drawing.Image)(resources.GetObject("pen.Image")));
            this.pen.Name = "pen";
            this.pen.Size = new System.Drawing.Size(197, 22);
            this.pen.Text = "Pen";
            // 
            // style
            // 
            this.style.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.solid,
            this.dot,
            this.dashDotDot});
            this.style.Name = "style";
            this.style.Size = new System.Drawing.Size(103, 22);
            this.style.Text = "Style";
            // 
            // solid
            // 
            this.solid.CheckOnClick = true;
            this.solid.Name = "solid";
            this.solid.Size = new System.Drawing.Size(138, 22);
            this.solid.Text = "Solid";
            this.solid.Click += new System.EventHandler(this.solid_Click);
            // 
            // dot
            // 
            this.dot.Name = "dot";
            this.dot.Size = new System.Drawing.Size(138, 22);
            this.dot.Text = "Dot";
            this.dot.Click += new System.EventHandler(this.dot_Click);
            // 
            // dashDotDot
            // 
            this.dashDotDot.Name = "dashDotDot";
            this.dashDotDot.Size = new System.Drawing.Size(138, 22);
            this.dashDotDot.Text = "DashDotDot";
            this.dashDotDot.Click += new System.EventHandler(this.dashDotDot_Click);
            // 
            // color11
            // 
            this.color11.Image = ((System.Drawing.Image)(resources.GetObject("color11.Image")));
            this.color11.Name = "color11";
            this.color11.Size = new System.Drawing.Size(103, 22);
            this.color11.Text = "Color";
            this.color11.Click += new System.EventHandler(this.color11_Click);
            // 
            // help
            // 
            this.help.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutF1});
            this.help.Name = "help";
            this.help.Size = new System.Drawing.Size(44, 20);
            this.help.Text = "Help";
            // 
            // aboutF1
            // 
            this.aboutF1.Image = ((System.Drawing.Image)(resources.GetObject("aboutF1.Image")));
            this.aboutF1.Name = "aboutF1";
            this.aboutF1.ShortcutKeyDisplayString = "F1";
            this.aboutF1.ShortcutKeys = System.Windows.Forms.Keys.F1;
            this.aboutF1.Size = new System.Drawing.Size(144, 22);
            this.aboutF1.Text = "About      ";
            this.aboutF1.Click += new System.EventHandler(this.aboutF1_Click);
            // 
            // picDrawingSurface
            // 
            this.picDrawingSurface.BackColor = System.Drawing.Color.White;
            this.picDrawingSurface.Location = new System.Drawing.Point(63, 28);
            this.picDrawingSurface.Name = "picDrawingSurface";
            this.picDrawingSurface.Size = new System.Drawing.Size(903, 523);
            this.picDrawingSurface.TabIndex = 1;
            this.picDrawingSurface.TabStop = false;
            this.picDrawingSurface.MouseDown += new System.Windows.Forms.MouseEventHandler(this.picDrawingSurface_MouseDown);
            this.picDrawingSurface.MouseMove += new System.Windows.Forms.MouseEventHandler(this.picDrawingSurface_MouseMove);
            this.picDrawingSurface.MouseUp += new System.Windows.Forms.MouseEventHandler(this.picDrawingSurface_MouseUp);
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.tt);
            this.panel1.Controls.Add(this.width);
            this.panel1.Location = new System.Drawing.Point(63, 574);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(899, 40);
            this.panel1.TabIndex = 2;
            // 
            // tt
            // 
            this.tt.AutoSize = true;
            this.tt.Location = new System.Drawing.Point(21, 10);
            this.tt.Name = "tt";
            this.tt.Size = new System.Drawing.Size(35, 13);
            this.tt.TabIndex = 1;
            this.tt.Text = "label1";
            // 
            // width
            // 
            this.width.AutoSize = false;
            this.width.Location = new System.Drawing.Point(628, 0);
            this.width.Name = "width";
            this.width.Size = new System.Drawing.Size(271, 40);
            this.width.TabIndex = 0;
            this.width.Value = 3;
            this.width.Scroll += new System.EventHandler(this.width_Scroll);
            // 
            // instrument_panel
            // 
            this.instrument_panel.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.instrument_panel.AutoSize = false;
            this.instrument_panel.Dock = System.Windows.Forms.DockStyle.None;
            this.instrument_panel.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.upload,
            this.save1,
            this.open1,
            this.color1,
            this.exit1});
            this.instrument_panel.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.VerticalStackWithOverflow;
            this.instrument_panel.Location = new System.Drawing.Point(0, 28);
            this.instrument_panel.Name = "instrument_panel";
            this.instrument_panel.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.instrument_panel.Size = new System.Drawing.Size(60, 523);
            this.instrument_panel.Stretch = true;
            this.instrument_panel.TabIndex = 3;
            this.instrument_panel.Text = "toolStrip1";
            // 
            // upload
            // 
            this.upload.AutoSize = false;
            this.upload.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("upload.BackgroundImage")));
            this.upload.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.upload.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.upload.Name = "upload";
            this.upload.Size = new System.Drawing.Size(60, 60);
            this.upload.Text = "toolStripButton1";
            this.upload.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // save1
            // 
            this.save1.AutoSize = false;
            this.save1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("save1.BackgroundImage")));
            this.save1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.save1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.save1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.save1.Name = "save1";
            this.save1.Size = new System.Drawing.Size(60, 60);
            this.save1.Text = "toolStripButton2";
            // 
            // open1
            // 
            this.open1.AutoSize = false;
            this.open1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("open1.BackgroundImage")));
            this.open1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.open1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.open1.Name = "open1";
            this.open1.Size = new System.Drawing.Size(60, 60);
            this.open1.Text = "toolStripButton3";
            this.open1.Click += new System.EventHandler(this.open1_Click);
            // 
            // color1
            // 
            this.color1.AutoSize = false;
            this.color1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("color1.BackgroundImage")));
            this.color1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.color1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.color1.Name = "color1";
            this.color1.Size = new System.Drawing.Size(60, 60);
            this.color1.Text = "toolStripButton4";
            this.color1.Click += new System.EventHandler(this.color1_Click);
            // 
            // exit1
            // 
            this.exit1.AutoSize = false;
            this.exit1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("exit1.BackgroundImage")));
            this.exit1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.exit1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.exit1.Name = "exit1";
            this.exit1.Size = new System.Drawing.Size(60, 60);
            this.exit1.Text = "toolStripButton5";
            this.exit1.Click += new System.EventHandler(this.exit1_Click);
            // 
            // panel2
            // 
            this.panel2.Location = new System.Drawing.Point(56, 24);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(943, 544);
            this.panel2.TabIndex = 4;
            // 
            // PainLite
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(999, 609);
            this.Controls.Add(this.instrument_panel);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.picDrawingSurface);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.panel2);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "PainLite";
            this.Text = "Form1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picDrawingSurface)).EndInit();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.width)).EndInit();
            this.instrument_panel.ResumeLayout(false);
            this.instrument_panel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.MenuStrip menuStrip1;
		private System.Windows.Forms.ToolStripMenuItem file;
		private System.Windows.Forms.ToolStripMenuItem newToolStripMenuItem;
		private System.Windows.Forms.ToolStripMenuItem open;
		private System.Windows.Forms.ToolStripMenuItem save;
		private System.Windows.Forms.ToolStripMenuItem exit;
		private System.Windows.Forms.ToolStripMenuItem edit;
		private System.Windows.Forms.ToolStripMenuItem undo;
		private System.Windows.Forms.ToolStripMenuItem reno;
		private System.Windows.Forms.ToolStripMenuItem pen;
		private System.Windows.Forms.ToolStripMenuItem style;
		private System.Windows.Forms.ToolStripMenuItem solid;
		private System.Windows.Forms.ToolStripMenuItem dot;
		private System.Windows.Forms.ToolStripMenuItem dashDotDot;
		private System.Windows.Forms.ToolStripMenuItem color11;
		private System.Windows.Forms.ToolStripMenuItem help;
		private System.Windows.Forms.ToolStripMenuItem aboutF1;
		private System.Windows.Forms.PictureBox picDrawingSurface;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.TrackBar width;
		private System.Windows.Forms.ToolStrip instrument_panel;
		private System.Windows.Forms.ToolStripButton upload;
		private System.Windows.Forms.ToolStripButton save1;
		private System.Windows.Forms.ToolStripButton open1;
		private System.Windows.Forms.ToolStripButton color1;
		private System.Windows.Forms.ToolStripButton exit1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label tt;
    }
}

